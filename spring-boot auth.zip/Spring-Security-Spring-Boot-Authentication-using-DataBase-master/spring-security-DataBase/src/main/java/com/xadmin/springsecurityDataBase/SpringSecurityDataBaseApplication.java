package com.xadmin.springsecurityDataBase;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityDataBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityDataBaseApplication.class, args);
	}

}
