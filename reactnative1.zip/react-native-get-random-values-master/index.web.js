// The web platform already has support for getRandomValues
